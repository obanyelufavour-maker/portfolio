# 3 Automotive Sample Videos for Your Portfolio

## VIDEO 1 — "Don't Ignore That Sound"
Length: 20–24 seconds
Format: 9:16 vertical
Goal: advertise general vehicle inspection/service.

PROMPT:
Create a realistic, premium automotive social-media advertisement in vertical 9:16 format. Scene 1: a Nigerian driver inside a modern car hears an unusual engine sound and looks concerned. Scene 2: close cinematic shots of the car dashboard and engine area, no dangerous driving. Scene 3: a professional Nigerian auto technician in a clean workshop performs a careful vehicle inspection using diagnostic equipment. Scene 4: the technician confidently checks the vehicle while the customer looks relieved. Scene 5: clean workshop exterior and polished vehicle. Use realistic human movement, natural Nigerian setting, professional commercial lighting, smooth camera movement, crisp details, shallow depth of field and modern automotive advertising style. Add space for on-screen text: "Strange sound? Don't ignore it." then "Get your vehicle checked by professionals." End with "CHUMA BENZ AUTO MECHATRONIC LIMITED" and "Contact us to book a service." Do not invent a phone number.

VOICEOVER:
"That strange sound from your car may be a warning. Don't wait until a small problem becomes a bigger one. Get your vehicle properly checked by professionals. Drive with confidence."

MUSIC/SFX:
Modern low-volume corporate/automotive beat, subtle engine and workshop ambience. Voice must remain clear.

---

## VIDEO 2 — "Know What's Wrong"
Length: 20–24 seconds
Format: 9:16 vertical
Goal: advertise auto diagnostics.

PROMPT:
Create a realistic high-end automotive diagnostic advertisement in vertical 9:16 format. Scene 1: close-up of a car dashboard showing a generic warning light, with no fake brand logo. Scene 2: professional Nigerian automotive technician connects a modern diagnostic scanner to the vehicle. Scene 3: close-up of the scanner screen showing generic diagnostic information without claiming a specific real fault. Scene 4: technician explains the inspection to the customer beside the vehicle. Scene 5: polished car leaving a professional workshop. Use cinematic commercial lighting, realistic Nigerian workshop environment, smooth gimbal camera movement, natural facial expressions, realistic hands, premium automotive color grading and crisp 4K-style detail. Add text: "Warning light on?" "Don't guess. Diagnose." End: "Professional Auto Diagnostics" and "CHUMA BENZ AUTO MECHATRONIC LIMITED". Do not invent contact details.

VOICEOVER:
"Is your warning light on? Don't guess what's wrong. Proper diagnostics can help identify the problem so you can make an informed decision. Get your vehicle checked professionally."

MUSIC/SFX:
Clean modern technology beat with subtle scanner beeps. Keep music under the voice.

---

## VIDEO 3 — "Trust Your Car to Professionals"
Length: 25–30 seconds
Format: 9:16 vertical
Goal: brand-awareness reel for an auto-mechatronic business.

PROMPT:
Create a premium 30-second automotive brand reel for a professional Nigerian auto-mechatronic workshop. Start with an energetic exterior shot of a clean workshop. Cut to a technician opening the workshop, preparing tools and putting on professional protective equipment. Show quick cinematic shots of vehicle inspection, diagnostic equipment, careful mechanical work and quality-control checks. Show a customer receiving an explanation from the technician. Finish with a clean vehicle driving away from the workshop. The atmosphere should communicate professionalism, trust, precision and modern automotive expertise. Use realistic Nigerian people and environment, natural body movement, cinematic commercial lighting, smooth tracking shots, macro details of tools and vehicle components, shallow depth of field and premium social-media advertising style. No dangerous driving, no fake claims, no invented certifications. End card text: "CHUMA BENZ AUTO MECHATRONIC LIMITED" "Professional. Reliable. Precise." "Contact us to learn more." Do not invent a phone number.

VOICEOVER:
"Your vehicle deserves more than guesswork. From inspection and diagnostics to careful automotive service, choose professionals who take your vehicle seriously. Chuma Benz Auto Mechatronic Limited — professional, reliable, precise."

MUSIC/SFX:
Confident modern automotive/corporate instrumental with subtle workshop sounds. Voice clear and professional.

---

## IMPORTANT PORTFOLIO NOTE
These are SPEC SAMPLE CONCEPTS made to demonstrate your creative ability. Do not claim that Chuma Benz commissioned them or that you have worked for the company unless they actually hire you.

Before sending your application:
1. Generate the 3 videos.
2. Add them to the portfolio page by replacing the "VIDEO SAMPLE" boxes with your actual video links/files.
3. Put your real email and WhatsApp number in the contact section.
4. Keep the videos vertical (9:16) and around 20–30 seconds.
5. If you use AI-generated footage, present yourself honestly as an AI/video content creator.
